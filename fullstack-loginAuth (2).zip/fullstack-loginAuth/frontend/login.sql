-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2024 at 02:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `signup`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`) VALUES
(1, 'Khusboo', 'k@gmail.com', '$2b$10$oFvZ1wTEpirQoB1cjx93OOVY/Dw8MQ07hDKOfNo4qcCcR0ZcQWyg2'),
(2, 'kartika', 'kk@gmail.com', '$2b$10$gx0zUGIXLgQ2iEqc1.Ba6OqHEVHL6xwHSr81M4KfuiWSrbg15FP.u'),
(3, 'kapil', 'k@gmail.com', '$2b$10$yGn3Xzw24Vys2CTwSpjNMOrE2DIj9Dw96nztgxxeFswp5K8G6ZcGe'),
(4, 'Rahul', 'rahul@gmail.com', '$2b$10$vwrtSFpd9Le0tLwj4pEgn.8UUBV5FbOVIzofqeclLet1oO8AKWZCW'),
(5, 'ayus k', 'ak@gmail.com', '$2b$10$tHgTVUCog4rLXCis2remX.g0XVQAhEgo8SoYtG1CVVoldgwOV4wge');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
